# Authors

- Guillaume Lessard (qector-decoder-v3) - decoder design, implementation,
  verification suites, certification artifacts.

Verifiers: Colab Linux x86_64 runners (certs dated 2026-09-09).
