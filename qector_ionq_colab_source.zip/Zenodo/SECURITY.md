# Security Policy

## Scope

This public record contains verification DATA ONLY: certificates, Z3 oracle
output, performance numbers, API stub, and reference benchmark scripts.
It contains no proprietary Rust source, no compiled wheels, no license keys,
and no API tokens. There is nothing here that grants decoder access.

## Reporting a vulnerability

Do not open a public issue for security-sensitive findings. Contact the
qector-decoder-v3 maintainer directly with: affected version, reproduction
steps, and impact. Expect acknowledgement within 7 days.

## Operational notes

- Never commit `LICENSE_KEYS.md`, `gen_keys.py` output, `QECTOR_IONQ_KEY`,
  or `IONQ_API_KEY` values to a public repo. The restricted frozen package
  is the only place that may hold NDA keys.
- The hardware bridge reads the IonQ key from the `IONQ_API_KEY`
  environment variable only; no key is hardcoded in public files.
- Verify downloads with `SHA256SUMS.txt` before use.
