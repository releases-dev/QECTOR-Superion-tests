# Performance Certification (2026-09-09T12:43:39.854848+00:00)

Decoder 1.7.7-production | IonQ Superion 256 | status GREEN

| Threads | Q70/s | Q102/s | Gross/s |
|---|---|---|---|
| 1 | 7110.0 | 3022.0 | 3941.0 |
| 2 | 6431.0 | 3291.0 | 4211.0 |
