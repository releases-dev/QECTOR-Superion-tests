# Q102 Production Certification (2026-09-09T12:43:23.237102+00:00)

status GREEN | 1.7.7-production | 31/31 passed

- [x] q102 dims 102/102 — 102/102
- [x] q70 dims 70/70 — 70/70
- [x] gross dims 144/144 — 144/144
- [x] version pinned — 1.7.7-production
- [x] hardware pinned — IonQ Superion 256
- [x] Hx shape 51x102 — (51, 102)
- [x] Hz shape 51x102 — (51, 102)
- [x] orthogonality Hx@Hz.T=0 — CSS commutativity
- [x] binary matrices — GF(2)
- [x] Q102 Rust==Appendix-C — 102x102 exact
- [x] Q102 row-weight all 8 — min=8 max=8
- [x] Q70 Rust binary + row-w8>0 — (70, 70) nnz=420
- [x] Gross Rust binary + row-w8>0 — (144, 144) nnz=864
- [x] Q102 w2 5151/5151 — 2.75s
- [x] Q102 w3 sampled 2000 — 1.12s
- [x] Q102 w4 sampled 1000 — 0.43s
- [x] Q102 w5 sampled 500 — 0.28s
- [x] Q70 random 500 faithful — fails=0
- [x] Q102 random 500 faithful — fails=0
- [x] Gross random 500 faithful — fails=0
- [x] batch==single — B=8
- [x] determinism x3 — identical outputs
- [x] length-mismatch raises — 101 vs 102
- [x] empty syndrome raises — 0 vs 102
- [x] zero->zero — no false correction
- [x] erasure all->zero — full-erasure fallback
- [x] heterogeneous priors — heterogeneous_qubit_priors
- [x] uniform schedule reset — uniform
- [x] streaming update/flush — SEC path
- [x] strict_verify toggle — strict mode API
- [x] BPOSDDecoder smoke — 102-bit output
