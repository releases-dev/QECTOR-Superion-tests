# Math Certification (2026-09-09T12:43:14.645724+00:00)

GREEN 24 proofs

- [x] phi(0)=inf — 
- [x] phi(1e-6)>10 — 14.51
- [x] phi(20)=0 — 
- [x] phi continuity at 0.25 — LUT/exact seam
- [x] phi involution grid — max_err=2.5e-13
- [x] phi monotonic decreasing — kernel shape
- [x] LLR limits — LLR(1e-3)=6.907
- [x] LLR monotonic — prior order
- [x] orthogonality Q102 — CSS
- [x] audit Q102 — (102, 102)
- [x] row-weight Q102 — w=8
- [x] audit Q70 — (70, 70)
- [x] audit Gross — (144, 144)
- [x] faults Q102 w1 full — 102/102 0.06s
- [x] faults Q102 w2 full — 5151/5151 1.96s
- [x] faults Q102 w3 sampled(1500) — 1500/1500 0.62s
- [x] faults Gross w1 full — 144/144 0.04s
- [x] faults Gross w2 full — 10296/10296 3.40s
- [x] faults Q70 w1 full — 70/70 0.01s
- [x] faults Q70 w2 full — 2415/2415 0.43s
- [x] zero->zero — 
- [x] determinism — 
- [x] erasure all->zero — 
- [x] batch==single — 
