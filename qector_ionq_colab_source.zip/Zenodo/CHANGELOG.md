# Changelog

## 1.7.7 (2026-09-09) - current public record

- Production decoder 1.7.7-production (IonQ Superion 256 / Walking Cat).
- Codes: Q70 (70/70), Q102 (102/102, Appendix-C, row-weight 8), Gross-144.
- Verification published: smoke GREEN, math 24/24, Q102 production 31/31
  (full 5151 weight-2 scan), qector test 23/23, performance CPU + GPU T4,
  Z3 SMT oracle SAT on all three codes.
- Colab FULL suite (8 cells, CPU + optional CUDA build, full test matrix).
- GPU test script (T4/A100-safe, CPU fallback, batch 64/512/2000).
- Frozen restricted package (wheels Linux cp313 + Windows cp311/cp312)
  with SHA256SUMS; public record carries data + redacted source only.

## 1.7.6 / 1.7.5

- Prior Windows wheel checkpoints, kept in the restricted frozen package
  for compatibility. No public data published for these versions.
