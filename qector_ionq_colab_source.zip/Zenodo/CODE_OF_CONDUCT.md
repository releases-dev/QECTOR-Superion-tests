# Code of Conduct

Be professional and factual. No harassment, no hate speech, no spam.
Verification claims require evidence (logs, machine info, script versions).
Maintainers may remove abusive content and restrict repeat offenders.
Report conduct issues to the qector-decoder-v3 maintainer.
