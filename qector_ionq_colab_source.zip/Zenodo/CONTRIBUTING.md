# Contributing

This public record is a frozen verification snapshot, not a development
repo. The decoder source is proprietary and lives in the restricted package.

Accepted contributions:

- Corrections to certificates, documentation, or benchmark scripts in
  `redacted_source/` (with reproduction evidence).
- Independent reproduction reports (machine, Python/numpy versions,
  commit of scripts used, full logs).

Not accepted here:

- Decoder source changes, wheel rebuilds, license-key requests.
  Those go through the qector-decoder-v3 maintainer under NDA.

Style: ASCII only in all text files (no smart quotes or em/en dashes),
one change per submission, update SHA256SUMS.txt when touching files.
