# Qector IonQ Decoder v1.7.7 - Public Verification Data

Public verification and certification artifacts for the Qector IonQ
Superion 256 / Walking Cat decoder v1.7.7-production, by Guillaume Lessard
(qector-decoder-v3).

Target hardware: IonQ Superion 256. Target architecture: Walking Cat
(arXiv:2604.19481). Codes: Q70 (70 qubits / 70 checks), Q102 (102/102,
Appendix-C, row-weight 8), Gross-144 (144/144).

## What is in this repo

- `certs/` - 10 GREEN certification files (JSON + Markdown): smoke test,
  math verification (24 proofs), Q102 production (31 checks), qector test
  suite (23 checks), performance benchmark.
- `proof_artifacts/certified_z3_oracle.json` (+ `.sha256`) - Z3 SMT solver
  oracle: Q70/Q102/Gross all SAT (schema qector-z3-oracle-v1).
- `performance_summary.csv` - Throughput: GPU Tesla T4 batch-2000
  (Q70 62826 / Q102 34402 / Gross 28643 shots/s) and CPU reference numbers
  in `certs/cert_performance.*`.
- `redacted_source/` - Public-safe reference code only: Python API stub
  (`qector_ionq.pyi`), thread-allocation wrapper, smoke test, math/CPU/
  performance/GPU benchmark scripts. No proprietary Rust source, no wheels,
  no license keys, no API tokens.
- `Colab_Linux_Build_Suite_FULL.ipynb` - 8-cell Colab build + CPU/GPU
  verification notebook (works on free T4 GPU runtime).
- `pyproject.toml`, `LICENSE-PROPRIETARY`, `SHA256SUMS.txt`, `NOTICE.txt`.

## Verification status

All suites GREEN on Linux x86_64 (Python 3.13), 2026-09-09:
math 24/24, Q102 production 31/31 (incl. full 5151-pair weight-2 scan),
qector test 23/23, smoke 0 failures, Z3 oracle pass, SHA256 verified.

## Reproduce (CPU-only, no wheel needed)

Pure-Python reference checks run without the proprietary binary:

```
python redacted_source/qector_ionq_math_verification.py
python redacted_source/qector_ionq_cpu_benchmark.py
```

Full binary verification requires the restricted frozen package
(wheels under NDA, see NOTICE.txt): 10.5281/zenodo.22676194.

## License and citation

Code and decoder: proprietary, see LICENSE-PROPRIETARY and NOTICE.txt.
Verification data in `certs/`, `proof_artifacts/`, `performance_summary.csv`
is shared under CC-BY-4.0 (see DATA_LICENSE.txt); cite as below.
See CITATION.cff, AUTHORS.md, CHANGELOG.md, SECURITY.md.
