#!/usr/bin/env python3
# PROPRIETARY AND CONFIDENTIAL
# Copyright (c) 2026 Guillaume Lessard / qector-decoder-v3
# All Rights Reserved. NDA evaluation only. Do not redistribute.

"""qector_ionq_gpu_test.py - FULL GPU suite (T4/A100-safe, CPU-fallback)."""

import os, sys, time, subprocess

os.environ.setdefault("RAYON_NUM_THREADS","1")

def sh(c):

    print(f"$ {c}")

    r=subprocess.run(c,shell=True)

    print(f"exit={r.returncode}")

    return r.returncode

print("="*70); print("GPU ENV"); print("="*70)

sh("nvidia-smi"); sh("nvcc --version")

try:

    import torch

    print("torch",torch.__version__,"cuda=",torch.cuda.is_available())

    if torch.cuda.is_available(): print(torch.cuda.get_device_properties(0))

except Exception as e: print("torch missing:",e)

import numpy as np

import qector_ionq as q

from qector_ionq import IonQSuperionDecoder as D

print("qector",q.__version__,q.DECODER_VERSION)

for f in ["q70","q102","gross"]:

    d=getattr(D,f)(error_rate=1e-3)

    print(f"[{f}] backend={d.backend()} hash={d.artifact_hash}")

    if hasattr(d,"prefer_cuda"):

        try:

            ok=d.prefer_cuda(); print(f"  prefer_cuda={ok} backend={d.backend()}")

        except Exception as e: print(f"  prefer_cuda CPU-fallback (expected w/o cuda merge): {e}")

    else: print("  no CUDA flag (built --release default)")

    H=np.zeros((d.n_checks,d.n_qubits),dtype=np.uint8)

    for i,qs in enumerate(d.check_to_qubits):

        for qq in qs: H[i,qq]=1

    rng=np.random.default_rng(7)

    for B in [64,512,2000]:

        syns=np.concatenate([(H@(rng.random(d.n_qubits)<5e-3).astype(np.uint8)%2] for _ in range(B)).astype(np.uint8)

        _=d.decode_batch_flat(syns[:d.n_checks*4],4)

        t0=time.perf_counter(); out=np.array(d.decode_batch_flat(syns,B),dtype=np.uint8).reshape(B,d.n_qubits); dt=time.perf_counter()-t0

        ok=sum(bool(bool(((H@out[i])%2==syns[i*d.n_checks:(i+1)*d.n_checks]).all())) for i in range(B))

        print(f"  batch {B}: {dt*1000:.1f}ms {B/dt:.0f} shots/s faithful {ok}/{B}")

print("scopes:",q.py_latency_scopes() if hasattr(q,"py_latency_scopes") else "n/a")

print("GPU SUITE DONE")

