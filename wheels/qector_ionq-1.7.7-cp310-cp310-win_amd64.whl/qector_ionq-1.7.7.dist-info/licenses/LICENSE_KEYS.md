# qector-ionq 1.7.7 - NDA Evaluation Keys

**PROPRIETARY AND CONFIDENTIAL** - one key type, 8 keys total.
Distribute a single key per evaluator. Wheels only, under NDA.

| # | Key | Validity |
|---|-----|----------|
| 1 | `QIONQ7-EVAL01-20260909-3e6a26c32c49116a` | 7 days from 2026-09-09 |
| 2 | `QIONQ7-EVAL02-20260909-76e7b04c30032ef5` | 7 days from 2026-09-09 |
| 3 | `QIONQ7-EVAL03-20260909-7844b222a9598b20` | 7 days from 2026-09-09 |
| 4 | `QIONQ7-EVAL04-20260909-5944474a674fae13` | 7 days from 2026-09-09 |
| 5 | `QIONQ7-EVAL05-20260909-f0406a6aa1a16fd6` | 7 days from 2026-09-09 |
| 6 | `QIONQ7-EVAL06-20260909-cfae87077b0493a1` | 7 days from 2026-09-09 |
| 7 | `QIONQ7-EVAL07-20260909-d2073efce1a81fbc` | 7 days from 2026-09-09 |
| 8 (dev) | `QIONQ7-DEV000-00000000-e364e7d40d558b20` | no expiry, local dev only |

Use: `set QECTOR_IONQ_KEY=<key>` (Windows) or `export QECTOR_IONQ_KEY=<key>`,
or place the key in `~/.qector/ionq.key`. Check with:

```python
from qector_ionq import py_license_status
print(py_license_status())
```

`QECTOR_IONQ_ENFORCE=1` turns expired/invalid keys into hard errors.
